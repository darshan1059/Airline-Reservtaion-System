package com.app.enums;
/*
 * package com.codespy.airline.enums;
 * 
 * public enum DaysOfWeek { M("MONDAY"), T("TUESDAY"), W("WEDNESDAY"),
 * Th("THRUSDAY"), F("FRIDAY"), S("SATURDAY"), SU("SUNDAY");
 * 
 * public final String label;
 * 
 * private DaysOfWeek(String label) { this.label = label; }
 * 
 * }
 */
