/**
 * 
 */
package com.app.enums;

/**
 * @author CodeSpy
 *
 */
public enum SocialLogin {
	 GOOGLE
}
